#include<iostream>
using namespace std;
void merge_sort(int arr1[], int arr2[], int a)
{
    for (int i = 0; i < 2 * a; i++)
    {
        if (i % 2 == 0)
            arr3[i] = arr1[i / 2];
        else
            arr3[i] = arr2[i / 2];
    }
    merge_sort(arr3, arr3 + 2 * N);
    for (int i = 0; i < 2 * a; i++)
    {
        cout << arr3[i] << " ";
        if (i % 2 == 0)
            cout << "array-1" << endl;
        else
            cout << "array-2" << endl;
    }
}


