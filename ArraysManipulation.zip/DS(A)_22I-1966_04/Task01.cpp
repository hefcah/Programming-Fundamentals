#include<iostream>
using namespace std;
int* merge(int X[],int Y[],int Z[], int x, int y, int z);
int main()
{
	const int x=4;
	const int y=3;
	const int z=2;
	
	int X[x];
	int Y[y];
	int Z[z];
	cout<<"Enter value for array x"<<endl;
	for(int i=0;i<x;i++)
	{
	    cout<<i+1<<endl;
		cin>>X[i];
	}
	cout<<"Enter the value for array y"<<endl;
		for(int i=0;i<y;i++)
	{
		cout<<i+1<<endl;
		cin>>Y[i];
	}
	cout<<"Enter the value for array z"<<endl;
		for(int i=0;i<z;i++)
	{
		cout<<i+1<<": ";
		cin>>Z[i];
	}
	for(int i=0;i<x-1;i++)
	{
		for(int j=i+1;j<x;j++)
		{
			if(X[j]<X[i])
			{
				int imp=X[j];
				X[j]=X[i];
				X[i]=imp;
			}
		}
	}
	cout<<"For array x in sorted way"<<endl;
	for(int i=0;i<x;i++)
	{
	  cout<<X[i];
	}
		for(int i=0;i<y-1;i++)
	{
		for(int j=i+1;j<y;j++)
		{
			if(Y[j]<Y[i])
			{
				int imp=Y[j];
				Y[j]=Y[i];
				Y[i]=imp;
			}
		}
	}
	for(int i=0;i<z-1;i++)
	{
		for(int j=i+1;j<z;j++)
		{
			if(Z[j]<Z[i])
			{
				int imp=Z[j];
				Z[j]=Z[i];
				Z[i]=imp;
			}
		}
	}
	cout<<"array y in sorted way"<<endl;
		for(int i=0;i<y;i++)
	{
	  cout<<Y[i];
}
   cout<<"array of z in sorted way"<<endl;


	for(int i=0;i<z;i++)
	{
	  cout<<Z[i]; 
	  }
	  int* P= merge( X, Y, Z, x, y, z);	  
		  	for(int i=0;i<(x+y+z)-1;i++)
	{
		for(int j=i+1;j<(x+y+z);j++)
		{
			if(P[j]>P[i])
			{
				int imp=P[j];
				P[j]=P[i];
				P[i]=imp;
			}
		}
	} 
	  
	  
	  for(int i=0;i<x+y+z;i++)
	{   
		cout<<P[i];	
	}
	return 0;
}
	int* merge(int X[],int Y[],int Z[],int x,int y,int z)
	{		
		static int P[9];
			for(int i=0;i<x;i++)
		{  
		     P[i]=X[i];
			
		}
		
		for(int i=0;i<y;i++)
		{
			P[i+x]=Y[i];
		}
		for(int i=0;i<z;i++)
		{
			P[i+x+y]=Z[i];
		}
		return P;
	}
	

