 #include<iostream>
 using namespace std;
 int main (PrintMax,arr[],int a,int b)
 {
 
  cout<<"Enter value"<<endl;
  cin>>a;
  cout<<"enter value"<<endl;
  cin>>b;

    int j, max;
 
    for (int i = 0; i <= a-b; i++)
    {
        max = arr[i];
 
        for (j = 1; j < a; j++)
        {
            if (arr[i+j] > max)
               max = arr[i+j];
        }
        cout<<max<<endl;
    }
    return 0;
}

