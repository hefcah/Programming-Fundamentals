#include<iostream>
using namespace std;

void input(int *a,int *b)
{
     int i;

     cout<<"Enter the size of First Array : "<<endl;
     cin>>a;
     cout<<"Enter the elements of the First Array : "<<endl;
     int arr[*a];
     for(i=0;i<*a;i++)
     {
          &arr[i];
     }
     cout<<"Enter the size of Second Array : "<<endl;
     cin>>b;
     cout<<"Enter the elements of the Second Array : "<<endl;
     cin>>b;
