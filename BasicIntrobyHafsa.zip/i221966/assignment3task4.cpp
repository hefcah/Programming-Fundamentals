#include<iostream>
#include<string>
using namespace std;
int main()
{
int a,b,c;
int i=0;
//a=number that the user is gonna enter
//b=remainder when we'll take mod by 16
//firstly,we'll find mod by 16 to convert into hexadecimal
//if b<10 then we'll add 48,the reason for that will be that ASCII 1 will be generated.
//for b>10,ASCII in tens will be generated when 55 will be added
//the numbers 48 and 55 are approximations and are valid
//above hypothesis will generate the unit place while for tenth place,number will be divided by 16
//c is basically the answer being generated which is being used
cout<<"Enter Number"<<endl;
cin>>a;
while (a!=0)
{
b=a%16;
c=b<10?b+48:b+55;
a=a/16;
cout<<"Number in the form of hexadecimal is "<<c<<endl;
}
return 0;
}
