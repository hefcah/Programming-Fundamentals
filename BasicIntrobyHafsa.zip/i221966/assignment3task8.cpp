#include<iostream>
using namespace std;
int main()
{
 long long int num;
long long int k,m,o,q,s,u;
char j,l,n,p,r,t;
cout<<"Enter the number for code"<<endl;
cin>>num;
j=num/10000000000000000;
cout<<j<<endl;
k=num/100000000000000;
k=k%10;
cout<<k<<endl;
l=(num/1000000000000)%100;
cout<<l<<endl;
m=num/100000000000;
m=m%10;
cout<<m<<endl;
n=(num/10000000000)%100;
cout<<n<<endl;
o=num/100000000;
o=o%10;
cout<<o<<endl;
p=(num/1000000)%100;
cout<<p<<endl;
q=num/100000;
q=q%10;
cout<<q<<endl;
r=(num/1000)%100;
cout<<r<<endl;
s=num/100;
s=s%10;
cout<<s<<endl;
t=num%100;
cout<<t<<endl;
return 0;
}
