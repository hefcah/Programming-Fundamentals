#include<iostream>
#include<string>
using namespace std;
int main()
{
string a;
int j,k,l,m,n,h,o,p,q,r,s,t;
long int x;
cout<<"enter a word"<<endl;
cin>>a;
cout<<"Enter the roll number"<<endl;
cin>>x;
j=a[0];
k=a[1];
l=a[2];
m=a[3];
n=a[4];
h=a[5];
o=x/1000;
p=x/100;
p=p%10;
r=x/10;
r=r%10;
t=x%10;
cout<<j<<endl;
cout<<o<<endl;
cout<<k<<endl;
cout<<p<<endl;
cout<<l<<endl;
cout<<r<<endl;
cout<<m<<endl;
cout<<t<<endl;
cout<<n<<endl;
cout<<o<<endl;
cout<<h<<endl;
return 0;
}
