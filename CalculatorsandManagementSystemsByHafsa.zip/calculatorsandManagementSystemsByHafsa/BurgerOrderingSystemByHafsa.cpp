
#include<iostream>
using namespace std;
int main()
{
	float bill=0;
	string bun1="Creamy",bun2="Plain",bun3="Maya",bun4="wonder",bun;
	string cheese1="Cheddar",cheese2="Swiss",cheese3="Blue",cheese4="Brie",cheese,cheesechoice;
	string turnuptaste1="herbs",turnuptaste2="beef",turnuptaste3="olives",turnuptaste;
	string freshNup1="ketchup",freshNup2="kabab",freshNup3="chicken",freshNup4="grilled",freshNup,freshNuptaste,freshNupchoice;
	string sauce1="vinegar",sauce2="chilli",sauce3="soy",sauce4="Mayo",sauce,saucetaste,saucechoice;
	cout<<"Welcome to Burger Corner"<<endl;
	cout<<"Enter the type of bun you want to have"<<endl;
	cin>>bun;
	bill=bill+.72;
	int next;
	cout<<"press 1 if yes otherwise 0 for no"<<endl;
	cin>>next;
	switch (next)
	{
	case 1:
	cout<<"Enter the type of cheese"<<endl;
	cin>>cheese;
	bill=bill+.5;
	char c2;
	cout<<"Do you want another cheese Press Y/y for yes and N/n for no"<<endl;
	cin>>c2;
		switch (c2)
	{
		case 'Y':
		case 'y':
		cout<<"Add another item"<<endl;
		cin>>cheesechoice;
		bill=bill+.5;
		break;
		case 0:
			break;
	}

}
	cout<<"Enter an item from turn up category"<<endl;
	cin>>turnuptaste;
	bill=bill+1.2;
	cout<<"Choose item from freshNup"<<endl;
	cin>>freshNup;
	bill=bill+.2;
	char a2,a3;
	cout<<"Do you want another freshNup thenPress Y/y for yes and N/n for no"<<endl;
	cin>>a2;
	switch (a2)
	{
		case 'Y':
		case 'y':
		cout<<"Add another item"<<endl;
		cin>>freshNuptaste;
		bill=bill+.2;
		cout<<"Do you have to have another then Press Y/y for yes and N/n for no"<<endl;
		cin>>a3;
			switch (a3)
			{
			case 'Y':
			case 'y':
			cout<<"Add another item"<<endl;
			cin>>freshNupchoice;
			bill=bill+.5;
			break;
			}
	}
	cout<<"choose type of sauce(s) you want for your burger"<<endl;
	cin>>sauce;
	bill=bill+.3;
	char s2,s3;
	cout<<"Do you want add more sauces Press Y/y for yes and N/n for no"<<endl;
	cin>>s2;
	switch (s2)
	{
		case 'Y':
		case 'y':
		cout<<"Add another item"<<endl;
		cin>>saucetaste;
		bill=bill+.3;
		cout<<"Do you want add more sauces Press Y/y for yes and N/n for no"<<endl;
		cin>>s3;
			switch (s3)
			{
			case 'Y':
			case 'y':
			cout<<"Add another item"<<endl;
			cin>>saucechoice;
			bill=bill+.3;
			break;
			}
	}
cout<<"Your Bill is "<<bill<<"$"<<endl;
}
	

