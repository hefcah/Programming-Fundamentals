
#include<iostream>
using namespace std;
int main()
{
	int ID;
	int pswd;
	cout<<"Enter ID"<<endl;
	cout<<"Press any number from 100 to 114 since ID's are only lying over there"<<endl;
	cin>>ID;
	switch(ID)
	{
		case 100:
		case 101:	
		case 102:
		case 103:
		case 104:
		case 105:
		case 106:
		case 107:
		case 108:
		case 109:
			cout<<"Entered ID is an ID of a student"<<endl;
			cout<<"Dear Student!Kindly enter your password"<<endl;
			cin>>pswd;
		break;
		case 110:
		case 111:
		case 112:
			cout<<"Entered ID is of a Teacher"<<endl;
			cout<<"You are not supposed to enter your password"<<endl;
		break;
		case 113:
		case 114:
			cout<<"Entered ID is of IT staff"<<endl;
			cout<<"You are not supposed to enter your password"<<endl;
		break;
		
	break;
	}
switch((ID==100)&&(pswd==10220))
			{
				case 1:
						cout<<"Welcome to FASTCafe!Hope you are gonna have a good time here.Cheers!!!"<<endl;
						break;
				case 0:
						cout<<"You have entered an incorrect password"<<endl;
						break;
			}
switch((ID==101)&&(pswd==16010))
			{
				case 1:
						cout<<"Welcome to FASTCafe!Hope you are gonna have a good time here.Cheers!!!"<<endl;
						break;
				case 0:
						cout<<"You have entered an incorrect password"<<endl;
						break;
			}
switch((ID==102)&&(pswd==11002))
			{
				case 1:
						cout<<"Welcome to FASTCafe!Hope you are gonna have a good time here.Cheers!!!"<<endl;
						break;
				case 0:
						cout<<"You have entered an incorrect password"<<endl;
						break;
			}
			switch((ID==103)&&(pswd==22342))
			{
				case 1:
						cout<<"Welcome to FASTCafe!Hope you are gonna have a good time here.Cheers!!!"<<endl;
						break;
				case 0:
						cout<<"You have entered an incorrect password"<<endl;
						break;
			}
			switch((ID==104)&&(pswd==44323))
			{
				case 1:
						cout<<"Welcome to FASTCafe!Hope you are gonna have a good time here.Cheers!!!"<<endl;
						break;
				case 0:
						cout<<"You have entered an incorrect password"<<endl;
						break;
			}
			switch((ID==105)&&(pswd==33354))
			{
				case 1:
						cout<<"Welcome to FASTCafe!Hope you are gonna have a good time here.Cheers!!!"<<endl;
						break;
				case 0:
						cout<<"You have entered an incorrect password"<<endl;
						break;
			}
			switch((ID==106)&&(pswd==87685))
			{
				case 1:
						cout<<"Welcome to FASTCafe!Hope you are gonna have a good time here.Cheers!!!"<<endl;
						break;
				case 0:
						cout<<"You have entered an incorrect password"<<endl;
						break;
			}
			switch((ID==107)&&(pswd==99089))
			{
				case 1:
						cout<<"Welcome to FASTCafe!Hope you are gonna have a good time here.Cheers!!!"<<endl;
						break;
				case 0:
						cout<<"You have entered an incorrect password"<<endl;
						break;
			}
			switch((ID==108)&&(pswd==34562))
			{
				case 1:
						cout<<"Welcome to FASTCafe!Hope you are gonna have a good time here.Cheers!!!"<<endl;
						break;
				case 0:
						cout<<"You have entered an incorrect password"<<endl;
						break;
			}
			switch((ID==109)&&(pswd==44255))
			{
				case 1:
						cout<<"Welcome to FASTCafe!Hope you are gonna have a good time here.Cheers!!!"<<endl;
						break;
				case 0:
						cout<<"You have entered an incorrect password"<<endl;
						break;
			}

}
