
#include<iostream>
using namespace std;
int main ()
{
	float GBs,offnet,onnet,Bill=0;
	char package;
	cout<<"Choice a package"<<endl;
	cout<<endl;
	cout<<"Pack A"<<endl;
	cout<<"RS 100 per month, 1 GB data is provided"<<endl;
	cout<<"call RS 500 per month 100 OFF net minutes and 200 on net minutes"<<endl;
	cout<<endl;
	cout<<"Pack B"<<endl;
	cout<<"Rs 350 per month, 5 gb is provided"<<endl;
	cout<<"call RS 800 per month 250 OFF net minutes and 350 on net minutes"<<endl;
	cout<<endl;
	cout<<"Pack C"<<endl;
	cout<<"Rs 500 per month, 7 gb is provided"<<endl;
	cout<<"call RS 1000 per month 350 OFF net minutes and 300 on net minutes"<<endl;
	cout<<endl;
	cout<<"Pack D"<<endl;
	cout<<"Rs 1000 per month, unlimited Data is provided"<<endl;
	cout<<"call RS 1000 per month 750 OFF net minutes and 1000 on net minutes"<<endl;
	cout<<endl;
	cout<<"Whick package have you choose"<<endl;
	cin>>package;
	cout<<"Enter Gbs used"<<endl;
	cin>>GBs;
	cout<<"Enter off net min call"<<endl;
	cin>>offnet;
	cout<<"Enter on net min call"<<endl;
	cin>>onnet;
	if(package=='A')
	{
	Bill=600;
	if(GBs>1)
	GBs=GBs-1;
	Bill=Bill+((GBs*1024)/100)*20;
	}
	if(onnet>200)
	{
	onnet=onnet-200;
	Bill=Bill+(onnet*2);
	}
	if(offnet>100)
	{
		offnet=offnet-100;
		Bill=Bill+(offnet*3.75);
	}
	
	
	if(package=='B')
	{
	Bill=1500;
	if(GBs>5)
	GBs=GBs-5;
	Bill=Bill+((GBs*1024)/100)*15;
	}
	if(onnet>350)
	{
	onnet=onnet-350;
	Bill=Bill+(onnet*2);
	}
	if(offnet>250)
	{
		offnet=offnet-250;
		Bill=Bill+(offnet*3.25);
	}
		if(package=='C')
	{
	Bill=1500;
	if(GBs>7)
	GBs=GBs-7;
	Bill=Bill+((GBs*1024)/100)*13;
	}
	if(onnet>300)
	{
	onnet=onnet-300;
	Bill=Bill+(onnet*1.75);
	}
	if(offnet>350)
	{
		offnet=offnet-350;
		Bill=Bill+(offnet*2.75);
	}
		if(package=='D')
	{
	Bill=2500;
	if(GBs>50)
	GBs=GBs-50;
	Bill=Bill+((GBs*1024)/100)*10;
	}
	if(onnet>1000)
	{
	onnet=onnet-1000;
	Bill=Bill+(onnet*1);
	}
	if(offnet>750)
	{
		offnet=offnet-750;
		Bill=Bill+(offnet*1.5);
	}
	cout<<"The total Monthly Bill is :"<<Bill;
}
