
#include<iostream>
using namespace std;
int main()
{
	int combper,yourpercent,totalscore,info,edusys,opercent,apercent,matricpercent,intermediatepercent,subchoice,mathspercent,biopercent,percent,alumni;
	float secondary,higher,obtained,obt,cambridgesecondary,cambridgehigher;
	secondary=(matricpercent/100)*15;
	cambridgesecondary=(opercent/100)*15;
	higher=(intermediatepercent/100)*35;
	cambridgehigher=(apercent/100)*35;
	
	
	cout<<"Welcome to FAST University's Information Portal.Your queries will be entertained here.Thank You for joining."<<endl;
	cout<<"What do you want informtion for.For information regarding eligibility of admission press 1.For scholarships press 2"<<endl;
	cin>>info;
	if (info==1)
	{
		cout<<"What educational system was opted ?"<<endl;
		cout<<"If educational system O/A Levels press 1.If F.Sc press 2"<<endl;
		cin>>edusys;
		if (edusys==1)
		{
			cout<<"Enter O-Level Percentage"<<endl;
			cin>>opercent;
			cout<<"Enter A-Level Percentage"<<endl;
			cin>>apercent;
			opercent=opercent*15/100;
			apercent=apercent*35/100;
			combper=opercent+apercent;
		}
			else if (edusys==2)
			{
			cout<<"Enter matric Percentage"<<endl;
			cin>>matricpercent;
			cout<<"Enter F.Sc Percentage"<<endl;
			cin>>intermediatepercent;
			matricpercent=matricpercent*15/100;
			intermediatepercent=intermediatepercent*35/100;
			int combper=matricpercent+intermediatepercent;
		}
		cout<<"Select Subject Choice"<<endl;
		cout<<"For Pre-Medical Press 1.For Pre-Engineering press 2"<<endl;
		cin>>subchoice;
		if (subchoice==1)
		{
			cout<<"Add maths exams %age"<<endl;
			cin>>mathspercent;
		}
		else if (subchoice==2)
		{
			cout<<"Add bio exams %age"<<endl;
			cin>>biopercent;
		}
			if (biopercent>=50)
			{
				cout<<"Eligible for admission"<<endl;
			}
			else
			{
				cout<<"Not eligible for admission"<<endl;
			}
		}
		if(combper<75)
		{
		int req=75-combper;
		cout<<"You need "<<req<<" percent marks to be eligible"<<endl;
		}
		
		cout<<"Enter your percentage in admission test"<<endl;
		cin>>yourpercent;
		totalscore=yourpercent+combper;
		cout<<"ID\tDegree\t\t\t\tMerit"<<endl;
		cout<<"1\tBS Software Eng.\t\t79%"<<endl;
		cout<<"2\tBS Computer Science\t\t80%"<<endl;
		cout<<"3\tBS Artificial Intelligence\t75%"<<endl;
		cout<<"4\tBS Data Sciences\t\t76%"<<endl;
		cout<<"5\tBS Cyber Security\t\t77%"<<endl;
		cout<<"6\tBS Electrical ENgineering\t76%"<<endl;
		cout<<endl;
		cout<<endl;
		string choice;
		cout<<"Tell the degree you want to have according to your percentage"<<endl;
		cin>>choice;
}
