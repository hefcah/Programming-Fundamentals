
#include<iostream>
using namespace std;
int main()
  {
	char situation,hazardseliminationcheck,patientmovement,transportdecision;
	cout<<"Is the scene safe ?Press Y or y if safe else N or n if not"<<endl;
	cin>>situation;
	if (situation=='y'||situation=='Y')
	{
	 cout<<"Call for and await backup to make the scene safe"<<endl;
	}
	else if (situation=='N'||situation=='n')
	{
		cout<<"Has the hazards been eliminated? Y or y if yes else N or n if no"<<endl;
		cin>>hazardseliminationcheck;
	}
	if (hazardseliminationcheck=='Y'||hazardseliminationcheck=='y')
	{
		cout<<"Patient assessement"<<endl;
		cout<<"Primary survey"<<endl;
		cout<<"Critical Intervention"<<endl;
		cout<<"check for transport decision"<<endl;
	}
	else if (hazardseliminationcheck=='N'||hazardseliminationcheck=='n')
	{
		cout<<"Remove patient from hazards"<<endl;
		cout<<"Has the patient been moved safely ?Press Y or y if yes else N or n if no"<<endl;
		cin>>patientmovement;
		if (patientmovement=='Y'||patientmovement=='y')
		{
		 cout<<"Patient assessement"<<endl;
		 cout<<"Primary survey"<<endl;
		 cout<<"Critical Intervention"<<endl;
		}
		else if (patientmovement=='N'||patientmovement=='n')
		{
			cout<<"Call for and await backup to make the scene safe"<<endl;
		}
	cout<<"Does the patient needs transport ?Press Y or y if yes else N or n if no"<<endl;
	cin>>transportdecision;
		if (transportdecision=='y'||transportdecision=='Y')
		{
			cout<<"Load and Go"<<endl;
			cout<<"Check out for patient history"<<endl;
			cout<<"Package Patient"<<endl;
			cout<<"Begin transport"<<endl;
			cout<<"Check all vitals"<<endl;
			cout<<"Reassesement Survey"<<endl;
			cout<<"Begin treatement"<<endl;
			cout<<"Give the patient to a high level of care"<<endl;
		}
		else if (transportdecision=='N'||transportdecision=='n')
		{
			cout<<"Stay and Stabilize"<<endl;
			cout<<"Check out for patient history"<<endl;
			cout<<"Package Patient"<<endl;
			cout<<"Begin transport"<<endl;
			cout<<"Check all vitals"<<endl;
			cout<<"Reassesement Survey"<<endl;
			cout<<"Begin treatement"<<endl;
			cout<<"Give the patient to a high level of care"<<endl;
		}
	}
}
	
	
	
