
#include<iostream>
using namespace std;
int main()
{
	int bill=0;
	int addmore;
	int discount=0;
	int option;
    int food;
    int category;
    int burger;
    int Paratha_Roll;
    int PakistaniFoodType;
	cout<<"Hello Customer!Welcome to FAST Cafe,a hub of cuisines emballished with sweetness and chatkhaaras!"<<endl;
	cout<<"Kindly pick one out of following options : ( press numbers between 0-2 in order to select)"<<endl;
	cout<<"0 is for Takeway"<<endl;
	cout<<"1 is for Dine In"<<endl;
	cout<<"2 is for Delivery"<<endl;
	cout<<"Enter an Option"<<endl;
	cin>>option;
	if (option==0)
	{
	cout<<"Takeaway Menu"<<endl;
	}
	else if (option==1)
	{
		cout<<"Dine in"<<endl;
	}
	else if (option==2)
	{
		cout<<"Delivery"<<endl;
	}

	if (option==0)
	{
	cout<<"Welcome to Takeaway menu"<<endl;
	take:
	cout<<"0 burger/n1 paratha/n2 Paksiatani"<<endl;
	cout<<"Select food";
	cin>>food;
	
	if (food==0)
	{
	cout<<"Burger"<<endl;
	cout<<"Select the category for burger"<<endl;
	cout<<"[1]=PF_Ragra11(Rs.299)"<<endl;
	cout<<"	[2] OOP_Chatkhara (Rs: 499)"<<endl;
	cout<<"	[3] Hot_DS (Rs: 599)"<<endl; 
	cout<<"	[4] RedHot_Algo (Rs: 699)"<<endl;
	cout<<"Select Burger type"<<endl;
	cin>>burger;

	if (burger==1)
	{
		cout<<"PF_Ragra11"<<endl;
		bill=bill+299;
	}
		else if (burger==2)
	{
		cout<<"OOP_Chatkhara"<<endl;
		bill=bill+499;
	}
		else if (burger==3)
	{
		cout<<"Hot_DS"<<endl;
		bill=bill+599;
	}
		else if (burger==4)
	{
		cout<<"RedHot_Algo"<<endl;
		bill=bill+699;
	}
	}
	 if (food==1)
	{
		cout<<"Paratha Roll"<<endl;
		cout<<"[1] FAST_MalaiParatha (Rs: 299)"<<endl; 
		cout<<"[2] CS_Cheese Paratha (Rs: 399)"<<endl;
		cout<<"[3] DS_Dhamaka Paratha (Rs: 599)"<<endl;
		cout<<"[4] Al DoubleTrouble Paratha (Rs: 699)"<<endl;
		cout<<"[5] CY_SecurityTightParatha (Rs:499)"<<endl;
		cout<<"[6] SE_Meetha Paratha (Rs:199)"<<endl; 
		cout<<"[7] EE_ParhakuParatha (Rs:799)"<<endl; 
		cout<<"Select Paratha_Roll type"<<endl;
		cin>>Paratha_Roll;
	}
	if (Paratha_Roll==1)
	{
		cout<<"FAST_MalaiPratha"<<endl;
		bill=bill+299;
	}
		else if (Paratha_Roll==2)
	{
		cout<<"CS_CheeseParatha"<<endl;
		bill=bill+399;
	}
		else if (Paratha_Roll==3)
	{
		cout<<"DS_DhamakaParatha"<<endl;
		bill=bill+599;
	}
	else if (Paratha_Roll==4)
	{
		cout<<"AI_DoubleTroubleParatha"<<endl;
		bill=bill+699;
	}
	else if (Paratha_Roll==5)
	{
		cout<<"CY_SecurityTightParatha"<<endl;
		bill=bill+499;
	}
	else if (Paratha_Roll==6)
	{
		cout<<"SE_MeethaParatha"<<endl;
		bill=bill+199;
	}
	else if (Paratha_Roll==7)
	{
		cout<<"EE_ParhakuParatha"<<endl;
		bill=bill+799;
	}
	}
	else if (food==2)
	{
	cout<<"Pakistani Food"<<endl;
		cout<<"1) pointerHaleem (Rs: 199)"<<endl; 
        cout<<"2) loopNihaari (Rs: 199)"<<endl;
        cout<<"3) arrayDaal (Rs: 149)"<<endl;
    	cout<<"4) recursiveGhosht (Rs: 399)"<<endl;
		cout<<"Select Pakistani Food Type "<<endl;
		cin>>PakistaniFoodType;
	if (PakistaniFoodType==1)
	{
		cout<<"PointerHaleem"<<endl;
		bill=bill+199;
	}
	else if (PakistaniFoodType==2)
	{
		cout<<"loopNihari"<<endl;
		bill=bill+199;
	}
		else if (PakistaniFoodType==3)
	{
		cout<<"arrayDaal"<<endl;
		bill=bill+149;
	}
		else if (PakistaniFoodType==4)
	{
		cout<<"Recursive_Gosht"<<endl;
		bill=bill+399;

	}
}
	if(option==0)
	{
	cout<<"If you want to add more then press the button 1 :"<<endl;
	cin>>addmore;
	if(addmore==1)
	goto take;
	}
	if (option==1)
	{
		cout<<"Welcome to Dine-in menu"<<endl;
		dine:
		cout<<"0 burger/n1 paratha/n2 Paksiatani"<<endl;
		cout<<"Select food";
		cin>>food;
		
		if (food==0)
		{
	cout<<"Burger"<<endl;
	cout<<"Select the category for burger"<<endl;
	cout<<"[1]=PF_Ragra11(Rs.299)"<<endl;
	cout<<"	[2] OOP_Chatkhara (Rs: 499)"<<endl;
	cout<<"	[3] Hot_DS (Rs: 599)"<<endl; 
	cout<<"	[4] RedHot_Algo (Rs: 699)"<<endl;
	cout<<"Select Burger type"<<endl;
	cin>>burger;

	if (burger==1)
	{
		cout<<"PF_Ragra11"<<endl;
		bill=bill+299;
	}
		else if (burger==2)
	{
		cout<<"OOP_Chatkhara"<<endl;
		bill=bill+499;
	}
		else if (burger==3)
	{
		cout<<"Hot_DS"<<endl;
		bill=bill+599;
	}
		else if (burger==4)
	{
		cout<<"RedHot_Algo"<<endl;
		bill=bill+699;
	}
	}
	 if (food==1)
	{
		cout<<"Paratha Roll"<<endl;
		cout<<"[1] FAST_MalaiParatha (Rs: 299)"<<endl; 
		cout<<"[2] CS_Cheese Paratha (Rs: 399)"<<endl;
		cout<<"[3] DS_Dhamaka Paratha (Rs: 599)"<<endl;
		cout<<"[4] Al DoubleTrouble Paratha (Rs: 699)"<<endl;
		cout<<"[5] CY_SecurityTightParatha (Rs:499)"<<endl;
		cout<<"[6] SE_Meetha Paratha (Rs:199)"<<endl; 
		cout<<"[7] EE_ParhakuParatha (Rs:799)"<<endl; 
		cout<<"Select Paratha_Roll type"<<endl;
		cin>>Paratha_Roll;
	}
	if (Paratha_Roll==1)
	{
		cout<<"FAST_MalaiPratha"<<endl;
		bill=bill+299;
	}
		else if (Paratha_Roll==2)
	{
		cout<<"CS_CheeseParatha"<<endl;
		bill=bill+399;
	}
		else if (Paratha_Roll==3)
	{
		cout<<"DS_DhamakaParatha"<<endl;
		bill=bill+599;
	}
	else if (Paratha_Roll==4)
	{
		cout<<"AI_DoubleTroubleParatha"<<endl;
		bill=bill+699;
	}
	else if (Paratha_Roll==5)
	{
		cout<<"CY_SecurityTightParatha"<<endl;
		bill=bill+499;
	}
	else if (Paratha_Roll==6)
	{
		cout<<"SE_MeethaParatha"<<endl;
		bill=bill+199;
	}
	else if (Paratha_Roll==7)
	{
		cout<<"EE_ParhakuParatha"<<endl;
		bill=bill+799;
	}
	}
	else if (food==2)
	{
	cout<<"Pakistani Food"<<endl;
		cout<<"1) pointerHaleem (Rs: 199)"<<endl; 
        cout<<"2) loopNihaari (Rs: 199)"<<endl;
        cout<<"3) arrayDaal (Rs: 149)"<<endl;
    	cout<<"4) recursiveGhosht (Rs: 399)"<<endl;
		cout<<"Select Pakistani Food Type "<<endl;
		cin>>PakistaniFoodType;
	if (PakistaniFoodType==1)
	{
		cout<<"PointerHaleem"<<endl;
		bill=bill+199;
	}
	else if (PakistaniFoodType==2)
	{
		cout<<"loopNihari"<<endl;
		bill=bill+199;
	}
		else if (PakistaniFoodType==3)
	{
		cout<<"arrayDaal"<<endl;
		bill=bill+149;
	}
		else if (PakistaniFoodType==4)
	{
		cout<<"Recursive_Gosht"<<endl;
		bill=bill+399;
	}
		

}
		if(option==1)
		{
		
		cout<<"If you want to add more then press the button 1 :"<<endl;
		cin>>addmore;
		if(addmore==1)
		goto dine;
	}
	
	
	if (option==2)
	{
		cout<<"Welcome to Delivery menu"<<endl;
		deliver:
		cout<<"0 burger,1 paratha,2 Paksiatani"<<endl;
		cout<<"Select food";
		cin>>food;
		if (food==0)
		{
	cout<<"Burger"<<endl;
	cout<<"Select the category for burger"<<endl;
	cout<<"[1]=PF_Ragra11(Rs.299)"<<endl;
	cout<<"	[2] OOP_Chatkhara (Rs: 499)"<<endl;
	cout<<"	[3] Hot_DS (Rs: 599)"<<endl; 
	cout<<"	[4] RedHot_Algo (Rs: 699)"<<endl;
	cout<<"Select Burger type"<<endl;
	cin>>burger;

	if (burger==1)
	{
		cout<<"PF_Ragra11"<<endl;
		bill=bill+299;
	}
		else if (burger==2)
	{
		cout<<"OOP_Chatkhara"<<endl;
		bill=bill+499;
	}
		else if (burger==3)
	{
		cout<<"Hot_DS"<<endl;
		bill=bill+599;
	}
		else if (burger==4)
	{
		cout<<"RedHot_Algo"<<endl;
		bill=bill+699;
	}
	}
	 if (food==1)
	{
		cout<<"Paratha Roll"<<endl;
		cout<<"[1] FAST_MalaiParatha (Rs: 299)"<<endl; 
		cout<<"[2] CS_Cheese Paratha (Rs: 399)"<<endl;
		cout<<"[3] DS_Dhamaka Paratha (Rs: 599)"<<endl;
		cout<<"[4] Al DoubleTrouble Paratha (Rs: 699)"<<endl;
		cout<<"[5] CY_SecurityTightParatha (Rs:499)"<<endl;
		cout<<"[6] SE_Meetha Paratha (Rs:199)"<<endl; 
		cout<<"[7] EE_ParhakuParatha (Rs:799)"<<endl; 
		cout<<"Select Paratha_Roll type"<<endl;
		cin>>Paratha_Roll;
	}
	if (Paratha_Roll==1)
	{
		cout<<"FAST_MalaiPratha"<<endl;
		bill=bill+299;
	}
		else if (Paratha_Roll==2)
	{
		cout<<"CS_CheeseParatha"<<endl;
		bill=bill+399;
	}
		else if (Paratha_Roll==3)
	{
		cout<<"DS_DhamakaParatha"<<endl;
		bill=bill+599;
	}
	else if (Paratha_Roll==4)
	{
		cout<<"AI_DoubleTroubleParatha"<<endl;
		bill=bill+699;
	}
	else if (Paratha_Roll==5)
	{
		cout<<"CY_SecurityTightParatha"<<endl;
		bill=bill+499;
	}
	else if (Paratha_Roll==6)
	{
		cout<<"SE_MeethaParatha"<<endl;
		bill=bill+199;
	}
	else if (Paratha_Roll==7)
	{
		cout<<"EE_ParhakuParatha"<<endl;
		bill=bill+799;
	}
	}
	else if (food==2)
	{
	cout<<"Pakistani Food"<<endl;
		cout<<"1) pointerHaleem (Rs: 199)"<<endl; 
        cout<<"2) loopNihaari (Rs: 199)"<<endl;
        cout<<"3) arrayDaal (Rs: 149)"<<endl;
    	cout<<"4) recursiveGhosht (Rs: 399)"<<endl;
		cout<<"Select Pakistani Food Type "<<endl;
		cin>>PakistaniFoodType;
	if (PakistaniFoodType==1)
	{
		cout<<"PointerHaleem"<<endl;
		bill=bill+199;
	}
	else if (PakistaniFoodType==2)
	{
		cout<<"loopNihari"<<endl;
		bill=bill+199;
	}
		else if (PakistaniFoodType==3)
	{
		cout<<"arrayDaal"<<endl;
		bill=bill+149;
	}
		else if (PakistaniFoodType==4)
	{
		cout<<"Recursive_Gosht"<<endl;
		bill=bill+399;
	}
		

}
		if(option==2)
		{
		cout<<"If you want to add more then press the button 1 :"<<endl;
		cin>>addmore;
		if(addmore==1)
		goto deliver;
		}
		
cout<<"Your Bill without Discount : "<<bill<<endl;
	if(bill<1000)
	{
		discount=bill*5/100;
		bill=bill-discount;
	}
	else if(bill>1000&&bill<=1500)
	{
		discount=bill*10/100;
		bill=bill-discount;
	}
	else if(bill>1500&&bill<=2000)
	{
		discount=bill*15/100;
		bill=bill-discount;
	}
	else if(bill>2000&&bill<=2500)
	{
		discount=bill*20/100;
		bill=bill-discount;
	}
	else if(bill>2500&&bill<=3000)
	{
		discount=bill*30/100;
		bill=bill-discount;
	}
	else if(bill>3000)
	{
		discount=bill*50/100;
		bill=bill-discount;
	}
	cout<<"Your Bill with Discount : "<<bill<<endl;
	}

