
#include<iostream>
using namespace std;
int main()
{
	int price;
	float customduty,salestax,incometax,payable;
	cout<<"Enter Price of Purchased Cellphone"<<endl;
	cin>>price;
	if ((price>=0)&&(price<=50000))
	{
		cout<<"2% Custom Duty"<<endl;
		cout<<"4% Sales Tax"<<endl;
		cout<<"Income Tax = Nill"<<endl;
		customduty=(price/100)*2;
		salestax=(price/100)*4;
		payable=customduty+salestax+incometax;
		cout<<"Total Payable = Rs."<<payable<<endl;
	}
	else if  ((price>=50001)&&(price<=70000))
	{
	cout<<"5% Custom Duty"<<endl;
		cout<<"5% Sales Tax"<<endl;
		cout<<"Income Tax = Nill"<<endl;
		customduty=(price/100)*5;
		salestax=(price/100)*5;
		payable=customduty+salestax+incometax;
		cout<<"Total Payable = Rs."<<payable<<endl;	
	}
	else if  ((price>=70001)&&(price<=100000))
	{
	cout<<"9% Custom Duty"<<endl;
		cout<<"6% Sales Tax"<<endl;
		cout<<"5% Income Tax"<<endl;
		customduty=(price/100)*9;
		salestax=(price/100)*6;
		incometax=(price/100)*5;
		payable=customduty+salestax+incometax;
		cout<<"Total Payable = Rs."<<payable<<endl;	
	}
	else if  ((price>=100001)&&(price<=150000))
	{
	cout<<"17% Custom Duty"<<endl;
		cout<<"13% Sales Tax"<<endl;
		cout<<"6% Income Tax"<<endl;
		customduty=(price/100)*17;
		salestax=(price/100)*13;
		incometax=(price/100)*6;
		payable=customduty+salestax+incometax;
		cout<<"Total Payable = Rs."<<payable<<endl;	
	}
	else if  (price>=150001)
	{
	cout<<"20% Custom Duty"<<endl;
		cout<<"15% Sales Tax"<<endl;
		cout<<"18% Income Tax"<<endl;
		customduty=(price/100)*20;
		salestax=(price/100)*15;
		incometax=(price/100)*18;
		payable=customduty+salestax+incometax;
		cout<<"Total Payable = Rs."<<payable<<endl;	
	}
}
