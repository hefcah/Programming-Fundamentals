
#include<iostream>
using namespace std;
int main()
{
	int i=1;
	while(i<=4)
	{
		int j=1;
		while(j<=1)
		{
			cout<<"*";
			j++;
		}
		j=1;
		while(j<=7)
		{
			cout<<" ";
			j++;
		}
		j=1;
		while(j<=1)
		{
			cout<<"*";
			j++;
		}
		j=1;
		while(j<=4)
		{
			if(i==1)
				cout<<" *";
			else
				cout<<"  ";
			j++;
		}
		cout<<endl;
		i++;
	}

	i=1;
	while(i<=1)
	{
		int j=1;
		while(j<=9)
		{
			cout<<"* ";
			j++;
		}
		cout<<endl;
		i++;
	}

	i=0;
	while(i<=3)
	{
		int j=1;
		while(j<=4)
		{
			if(i==3)
				cout<<"* ";
			else
				cout<<"  ";
			j++;
		}
		j=1;
		while(j<=1)
		{
			cout<<"*";
			j++;
		}
		j=1;
		while(j<=7)
		{
			cout<<" ";
			j++;
		}
		j=1;
		while(j<=1)
		{
			cout<<"*";
			j++;
		}
		cout<<endl;
		i++;
	}
}
