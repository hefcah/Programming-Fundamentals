
#include<iostream>
using namespace std;
int main()
{
	for (int i=1;i<=4;i++)
	{
		for (int j=3;j>=i;j--)
		{
			cout<<" "<<endl;
		}
		for (int k=i-1;k>=(i-1);k--)
		{
			cout<<i-k<<endl;
		
		}
		cout<<endl;
	}
}
