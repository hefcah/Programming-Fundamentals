
#include <iostream>
using namespace std;

int main()
{
    int n = 5;
    int i = 1;

    while (i <= 5)
    {
        int j = 1;
        while (j <= i)
        {
            cout << "*";
            j++;
        }
        
        int k = 5;
        while (k > i)
        {
            cout << " ";
            k--;
        }

        int h = 4;
        while (h >= i)
        {
            cout << " ";
            h--;
        }

        int l = 1;
        while (l <= i)
        {
            cout << "*";
            l++;
        }

        cout << endl;
        i++;
    }

    int p = 1;
    while (p <= 4)
    {
        int q = 4;
        while (q >= p)
        {
            cout << "*";
            q--;
        }

        int r = 1;
        while (r <= p)
        {
            cout << " ";
            r++;
        }

        int s = 1;
        while (s <= p)
        {
            cout << " ";
            s++;
        }

        int t = 4;
        while (t >= p)
        {
            cout << "*";
            t--;
        }

        cout << endl;
        p++;
    }

    return 0;
}
